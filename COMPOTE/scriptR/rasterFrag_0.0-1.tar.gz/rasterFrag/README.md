# rasterFrag

This [R](https://www.r-project.org/) packages provide tools useful to calculate fragmentation index as describe in [Delay et al.](https://halshs.archives-ouvertes.fr/halshs-01155674).

## Installation

    library(devtools)
    install_github("pioucyril/rasterFrag")
## Build rasterFrag 

Still using `devtools` packages you can build as : 

    setwd(dir = "~/path/to/rasterFrag/")
    build()
    install.packages("~/path/to/rasterFrag_0.0-1.tar.gz", repos = NULL, type = "source")
    
TODO:
- probleme de chargement de cluster avant d'utiliser la fonction registerDoParallel dans fragSamples.R    
