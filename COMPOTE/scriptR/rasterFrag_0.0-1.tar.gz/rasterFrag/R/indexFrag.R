indexFrag <-
function(locRASTER,threshold=NULL,theopath=NULL, theo=NULL)
{
   require(SDMTools)
   if(is.null(threshold))threshold=mean(values(locRASTER))
   nCell=sum(values(locRASTER)>threshold,na.rm=T)
   nPotCell=sum(!is.na(values(locRASTER)))
   if(nCell<=1){
      return(1)
   }else{
     if(is.null(theopath) & (is.null(theo) | is.null(theo$ncell) | is.null(theo$nfragtheo))){
       #theo=prepareFragmentationTheo(nrepl=100 ,nrow=nrow(locRASTER),ncol=ncol(locRASTER))
       ncol=ncol(locRASTER)
       nrow=nrow(locRASTER)
       ress=data.frame(ncell=1:(ncol*nrow),nfragtheo=NA)
       resloc=numeric(100)
       for(repl in 1:100){
                 matt=matrix(0,ncol=ncol,nrow=nrow)
                 matt[sample(nrow*ncol,nCell)]=1
                 nfrag=max(ConnCompLabel(matt))
                 resloc[repl]=nfrag
       }
       theo=data.frame(ncell=nCell,nfragtheo=mean(resloc))
     }else{
       if(is.null(theo)){theo=load(theopath)}
     }
     ccl.mat = ConnCompLabel(locRASTER>threshold)
     #plot(ccl.mat,col=c('grey',rainbow(length(unique(ccl.mat))-1)))
     nFrag=max(values(ccl.mat),na.rm=T)
     nFragTheo= theo$nfragtheo[theo$ncell==nCell]  
     #correction eventuelle:
     #nFragTheo=(theo$nfragtheo[(theo$ncell)/10000==round(nCell/nPotCell,4)])*nPotCell/10000
     ps.data = PatchStat(ccl.mat)
     PAR=weighted.mean(ps.data$perim.area.ratio[-1],w=ps.data$area[-1])
     return(list(IF=nFrag/nFragTheo,PAR=PAR,nCell=nCell,nFrag=nFrag,theo=theo))
  }
}
