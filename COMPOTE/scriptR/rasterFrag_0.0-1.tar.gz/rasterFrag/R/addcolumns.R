addcolumns <-
function(sppdf,ndf)
{
   if(class(sppdf)!="SpatialPointsDataFrame")stop("sppdf has to be a SpatialPointsDataFrame")
   if(nrow(sppdf)!=nrow(ndf))stop("sppdf and ndf have to have the same row numbers")
   for(coli in 1:ncol(ndf)){
            sppdf[[colnames(ndf)[coli]]]=ndf[,coli]
   }
   return(sppdf)
}
