#' This function take as input sampling box provide by \code{samplingbox()} function.
#' 
#' 
#' @param my.samplingbox a list created by \code{samplingbox()} containing samples.
#' @param nbthread the number threads.
#' @param ns number of replication.
#' @param my.fragTheo fragTheo file
#' @return A \code{ns} length vector of  \code{indexFrag} results.
#' @examples
#' my.r <- fragSamples(my.Box, my.r,6,50)
#' 
fragSamples <- function(my.samplingbox,nbthread, ns, my.fragTheo){
  registerDoParallel(nbthread) #we will use 6 parrallel thread
  result = foreach(i = 1:ns,.packages=c('raster','spatstat'),.inorder=F) %dopar% {
    #for(i in 1:ns){
    b <- as.data.frame(raster.xy(my.samplingbox[[i]]))## get xy coord from on of our sample
    b$z <- 1 ## add Z column
    rrr <- rasterFromXYZ(b) ## convert in raster
    pol <- rasterToPolygons(rrr, dissolve=TRUE) ## Raster in polygon
    my.sample <- crop(my.r, pol) ## crop intital raster with ourt sample poly
    tmp_if <- indexFrag(my.sample, threshold = 2, theo=my.fragTheo) 
    tmp_if[[1]]
  }
  return(unlist(result))
}