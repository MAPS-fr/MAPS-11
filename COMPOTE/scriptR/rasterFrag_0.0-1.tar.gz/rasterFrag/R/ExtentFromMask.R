ExtentFromMask <-
function(maskfocal)
{
  xs=xFromCell(maskfocal,which(values(maskfocal)))
  ys=yFromCell(maskfocal,which(values(maskfocal)))  
  extent(min(xs)-(res(maskfocal)[1]/2),max(xs)+(res(maskfocal)[1]/2),min(ys)-(res(maskfocal)[2]/2),max(ys)+(res(maskfocal)[2]/2))
}
