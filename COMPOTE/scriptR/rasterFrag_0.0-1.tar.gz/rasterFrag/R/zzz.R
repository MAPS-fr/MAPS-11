.onAttach <- function(lib, pkg)
{
	 
}
.onLoad <- function(lib, pkg)
{
	 require(raster)
   require(SDMTools)
   require(spatstat)
   require(spatstat.utils)
   require(polyCub)
   require(doParallel)
   require(maptools)
}
