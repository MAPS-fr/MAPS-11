ppFromMask <-
function(maskfocal)
{
  xs=xFromCell(maskfocal,which(values(maskfocal)))
  ys=yFromCell(maskfocal,which(values(maskfocal))) 
  er=extent(maskfocal)
  xsh=res(maskfocal)[1]/2
  ysh=res(maskfocal)[1]/2
  ppp(xs,ys,xrange=c(er@xmin-xsh,er@xmax+xsh),yrange=c(er@ymin-ysh,er@ymax+ysh))
}
