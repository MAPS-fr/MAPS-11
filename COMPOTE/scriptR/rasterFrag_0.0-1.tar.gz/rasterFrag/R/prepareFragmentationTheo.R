prepareFragmentationTheo <-
function(nrepl=100,nrow=100,ncol=100){
  require(SDMTools)
  matt0=matrix(0,ncol=ncol,nrow=nrow)
  ress=data.frame(ncell=1:(ncol*nrow),nfragtheo=NA)
  pb <- txtProgressBar(title="Fragmentation theo progress",label="Initialization")
  for(ncell in 1:(ncol*nrow)){
            resloc=numeric(nrepl)
            for(repl in 1:nrepl){
                     matt=matt0
                     matt[sample(nrow*ncol,ncell)]=1
                     nfrag=max(ConnCompLabel(matt))
                     resloc[repl]=nfrag
            }
            ress[ncell,2]=mean(resloc)
            setTxtProgressBar(pb, ncell/(ncol*nrow),label="")
  }
  #plot(ress,type="l")
  close(pb)
  fragTheo=ress
  return(fragTheo)
}
