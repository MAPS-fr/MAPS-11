.trPaths <-
c("C:\\Users\\piou\\AppData\\Local\\Temp\\Tinn-R", "C:\\Users\\piou\\AppData\\Local\\Temp\\Tinn-R\\search.txt", 
"C:\\Users\\piou\\AppData\\Local\\Temp\\Tinn-R\\objects.txt", 
"C:\\Users\\piou\\AppData\\Local\\Temp\\Tinn-R\\file.r", "C:\\Users\\piou\\AppData\\Local\\Temp\\Tinn-R\\selection.r", 
"C:\\Users\\piou\\AppData\\Local\\Temp\\Tinn-R\\block.r", "C:\\Users\\piou\\AppData\\Local\\Temp\\Tinn-R\\lines.r", 
"C:\\Users\\piou\\AppData\\Local\\Temp\\Tinn-R\\reformat-input.r", 
"C:\\Users\\piou\\AppData\\Local\\Temp\\Tinn-R\\reformat-output.r"
)
