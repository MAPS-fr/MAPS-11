computeCElocal <-
function(locRASTER,threshold=NULL,clipregion=NULL)
{
   require(spatstat)
   if(is.null(threshold))threshold=mean(values(locRASTER))
   if(is.null(clipregion)){
       eR=extent(locRASTER)
       clipregion=owin(xrange=c(eR[1],eR[2]),yrange=c(eR[3],eR[4]))
   }
   mypp=ppFromMask(locRASTER>threshold)
   clarkevans(mypp,correction="guard",clipregion=clipregion)
}
