#' This function alow use to sample a raster X number of sampling zones (100X100 cells)
#' We use tow function (owin2Polygons and owin2SP) proposed by Adrian Baddeley in https://stat.ethz.ch/pipermail/r-sig-geo/2009-May/005781.html
#' 
#' @param my.raster a raster object.
#' @param nb the number of sample expected.
#' @return A liste of \code{nb} raster sample croped from \code{my.raster}.
#' @examples
#' my.Box <- samplingbox(my.r,50)
#' 

owin2Polygons <- function(x, id="1") {
  stopifnot(is.owin(x))
  x <- as.polygonal(x)
  closering <- function(df) { df[c(seq(nrow(df)), 1), ] }
  pieces <- lapply(x$bdry,
                   function(p) {
                     Polygon(coords=closering(cbind(p$x,p$y)),
                             hole=is.hole.xypolygon(p))  })
  z <- Polygons(pieces, id)
  return(z)
}

owin2SP <- function(x) {
  stopifnot(is.owin(x))
  y <- owin2Polygons(x)
  z <- SpatialPolygons(list(y))
  return(z)
}


samplingbox <- function(my.raster, nb){
  e <- extent(my.raster)
  # coerce to a SpatialPolygons object
  p <- as(e, 'SpatialPolygons')  
  
  nc <- as.owin.SpatialPolygons(p) #use polyCub package to convert sp in owin usable in spatstat
  
  ## defined number of sample
  pts <- rpoint(nb, win = nc) ## Create X randoms points inside raster
  
  
  ## sample big raster into N 100X100 raster cells
  rim <- as.im.RasterLayer(my.raster) ## convert with maptools package raster in im usable in spatstat
  
  Box <- owin(c(-50,50) * rim$xstep, c(-50,50) * rim$ystep) ## Define windows size 
  BoxesUnion <- MinkowskiSum(pts, Box) ## merge pts object and squard windows
  W <- intersect.owin(as.mask(rim), BoxesUnion) ## remove square parte outside the raster extend
  
  M <- as.mask(rim) 
  BoxList <- solapply(seq_len(npoints(pts)), 
                      function(i) intersect.owin(M, shift(Box, pts[i])))
  return(BoxList)
}