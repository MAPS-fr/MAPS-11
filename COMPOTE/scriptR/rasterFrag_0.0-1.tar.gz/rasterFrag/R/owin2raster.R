owin2raster <-
function(win,crs=NA){
  #ext=extent(c(win$xrange, win$yrange))
  nrows=nrow(win$m)
  raster(win$m[nrows:1,],xmn=win$xrange[1], xmx=win$xrange[2], ymn=win$yrange[1], ymx=win$yrange[2], crs=crs)#, template=ext)
}
