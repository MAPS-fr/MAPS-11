fractalD <-
function(locRASTER,threshold=NULL,output=FALSE) 
{
  smlDim=min(c(nrow(locRASTER),ncol(locRASTER)))
  m=matrix(locRASTER,nrow=nrow(locRASTER),ncol=ncol(locRASTER))
  if(nrow(locRASTER)!=ncol(locRASTER)){
    if(nrow(locRASTER)>ncol(locRASTER)){m<-m[1:smlDim,]}else{m<-m[,1:smlDim]}
  }
  powerl<- 1
  while(2^powerl<smlDim)powerl<-powerl+1
  powers <- 1:(powerl-1)
  boxsize <- 2^powers
  imgsize <- max(boxsize) 
  if(is.null(threshold)){threshold<-mean(m)}
  if(!any(m>=threshold)){return(0)}else{
    tsb<-m
    tsb[m >= threshold]<-1
    tsb[m <  threshold]<-0
    bv <- c()
    if(output)print('Box Size   Count   Total Box')
    for (b in boxsize) {
        bcount <- 0
        bstart <- seq(1,imgsize, by=b)
        totalbox <- 0
        for (x in bstart) {
            for (y in bstart) {
                totalbox <- totalbox+1
                xend <- x + b - 1
                yend <- y + b - 1
                if (any( tsb[ x:xend, y:yend ] > 0)) {
                    bcount <- bcount + 1
                }
            }
        }
        if(output)print(paste(b,bcount,totalbox))
        bv <- c(bv, bcount)
    }
    if(output)plot(log(1/boxsize), log(bv))
    dfl <- data.frame(x=log(1/boxsize), y=log(bv))
    dfl<-dfl[is.finite(dfl$y),]
    if(nrow(dfl)<=2){return(0)}
    model <- lm(y ~  x, dfl)
    if(output){abline(model)
    print(paste('fractal dimension =',model$coeff[2]))}
    #list(fdim=model$coeff[2],model=model)
    return(ifelse((is.na(coef(summary(model))[2,4]) | coef(summary(model))[2,4] > 0.05),0,model$coeff[2]))
  }
}
